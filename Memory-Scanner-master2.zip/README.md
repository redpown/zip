# Memory-Scanner
A tool created to scan for values in a program's memory and edit them, much like Cheat Engine.
